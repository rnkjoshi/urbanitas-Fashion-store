const express = require("express");
const { check } = require("express-validator");

const router = express.Router();

const usersControllers = require("../controllers/users-controllers");

//get all users
router.get("/", usersControllers.getAllUsers);

//get user by id
router.get("/:uid", usersControllers.getUserById);

//sign up new user
router.post(
  "/signup",
  [
    check("name").matches(/^[A-Za-z][A-Za-z\s.-]*$/),
    check("address").matches(/^[A-Za-z\d]/),
    check("email").normalizeEmail().isEmail(),
    check("phone").isNumeric().isLength({ min: 10, max: 10 }),
    check("password").matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#!$%^&*._-]{8,}$/,
      "i"
    ),
  ],
  usersControllers.signupUser
);

//login user
router.post("/login", usersControllers.loginUser);

//update user
router.patch(
  "/update/:uid",
  [
    check("address").matches(/^[A-Za-z\d]/),
    check("phone").isNumeric().isLength({ min: 10, max: 10 }),
    check("password").matches(
      /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d@#!$%^&*._-]{8,}$/,
      "i"
    ),
  ],
  usersControllers.updateUser
);

//delete user
router.delete("/:uid", usersControllers.deleteUser);

module.exports = router;
