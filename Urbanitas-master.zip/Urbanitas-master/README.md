# Urbanitas
A MERN stack project for viewing and prebooking of dresses from nearby shops/stores.
